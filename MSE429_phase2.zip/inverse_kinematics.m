clc;

% Test inverse kinematics by round-trip verification
count_possible = 0;
count_iteration = 0;
position_errors = [];
solution_errors = [];

for t1 = 0:5:270
    for t2 = 0:5:135
        for t3 = -45:5:135
            set_angle = [t1,t2,t3];
            count_iteration = count_iteration + 1;
            
            % Compute target position
            T_target = BaseToTool(set_angle(1), set_angle(2), set_angle(3));
            px_target = T_target(1,4); 
            py_target = T_target(2,4); 
            pz_target = T_target(3,4);
            
            % Get all IK solutions
            all_solutions = inverseKinematicsComplete(px_target, py_target, pz_target);
            
            if ~isempty(all_solutions)
                count_possible = count_possible + 1;
                
                % Initialize best solution tracking
                min_error = Inf;
                best_solution = [];
                
                % Evaluate each solution
                for i = 1:size(all_solutions,1)
                    % Compute forward kinematics for this solution
                    T_solution = BaseToTool(all_solutions(i,1), all_solutions(i,2), all_solutions(i,3));
                    px_sol = T_solution(1,4);
                    py_sol = T_solution(2,4);
                    pz_sol = T_solution(3,4);
                    
                    % Calculate position error (Euclidean distance)
                    position_error = norm([px_target - px_sol, py_target - py_sol, pz_target - pz_sol]);
                    
                    % Calculate joint angle error (optional)
                    angle_error = norm(set_angle - all_solutions(i,:));
                    
                    % Track best solution
                    if position_error < min_error
                        min_error = position_error;
                        best_solution = all_solutions(i,:);
                        best_angle_error = angle_error;
                    end
                end
                
                % Store errors for analysis
                position_errors(end+1) = min_error;
                solution_errors(end+1) = best_angle_error;
                
                % Display results for this case
                fprintf('\nOriginal: [%.1f, %.1f, %.1f]', set_angle);
                fprintf('\nBest match: [%.1f, %.1f, %.1f]', best_solution);
                fprintf('\nPosition error: %.6f units', min_error);
                fprintf('\nAngle error: %.2f degrees\n', best_angle_error);
            end
        end
    end
end

% Summary statistics
fprintf('\nTested %d configurations\n', count_iteration);
fprintf('Found solutions for %d configurations (%.1f%%)\n', ...
        count_possible, 100*count_possible/count_iteration);
fprintf('Mean position error: %.6f units\n', mean(position_errors));
fprintf('Max position error: %.6f units\n', max(position_errors));
fprintf('Mean angle error: %.2f degrees\n', mean(solution_errors));
fprintf('Max angle error: %.2f degrees\n', max(solution_errors));

% Plot position errors
figure;
histogram(position_errors);
title('Position Errors Distribution');
xlabel('Error (units)');
ylabel('Frequency');

% Plot angle errors
figure;
histogram(solution_errors);
title('Angle Errors Distribution');
xlabel('Error (degrees)');
ylabel('Frequency');

function T = BaseToTool(theta1_deg, theta2_deg, theta3_deg)
    % Closed-form forward kinematics solution
    % Inputs in degrees (converted internally)
    
    % Convert to radians
    theta1 = deg2rad(theta1_deg);
    theta2 = deg2rad(theta2_deg);
    theta3 = deg2rad(theta3_deg);
    
    % Shorthand notation
    c1 = cos(theta1); s1 = sin(theta1);
    c2 = cos(theta2); s2 = sin(theta2);
    c3 = cos(theta3); s3 = sin(theta3);
    
    % Combined terms
    c23 = c2*c3 - s2*s3;
    s23 = s2*c3 + c2*s3;
    
    % Position components
    px = 127.5*c1*c23 + 109*c1*c2 + 30*c1 + 47.7*s1;
    py = 127.5*s1*c23 + 109*s1*c2 + 30*s1 - 47.7*c1;
    pz = 127.5*s23 + 109*s2 + 97;
    
    % Rotation matrix
    T = [c1*c23, -s1, -c1*s23, px;
         s1*c23, c1, -s1*s23, py;
            s23,     0,      c23, pz;
              0,      0,        0,  1];
end

function [solutions] = inverseKinematicsComplete(px, py, pz)
    solutions = [];
    
    % First check if position is reachable
    K = px^2 + py^2 - 47.7^2;
    if K < 0
        error('Position not reachable: px^2 + py^2 < 47.7^2');
    end
    
    % Solution 1 for theta1
    theta1_1 = atan2(px, -py) - atan2(47.7, sqrt(K)) + pi;
    % Solution 2 for theta1 (alternative branch)
    theta1_2 = atan2(px, -py) + atan2(47.7, sqrt(K));
    
    % Process both theta1 solutions
    for theta1 = [theta1_1, theta1_2]
        c1 = cos(theta1);
        s1 = sin(theta1);
        
        % Handle division by zero cases
        if abs(c1) > 1e-10
            A = (px - 47.7*s1)/c1 - 30;
        else
            A = (py + 47.7*c1)/s1 - 30;
        end
        B = pz - 97;
        
        % Calculate cos(theta3)
        denom = 2*127.5*109;
        arg = (A^2 + B^2 - 127.5^2 - 109^2)/denom;
        
        % Check if solution exists
        if abs(arg) <= 1
            % Two solutions for theta3
            theta3_1 = acos(arg);
            theta3_2 = -theta3_1;
            
            for theta3 = [theta3_1, theta3_2]
                % Calculate theta2
                K1 = 127.5*cos(theta3) + 109;
                K2 = 127.5*sin(theta3);
                
                theta2 = atan2(B*K1 - A*K2, A*K1 + B*K2);
                
                % Store solution in degrees
                sol = [rad2deg(theta1), rad2deg(theta2), rad2deg(theta3)];
                sol = wrapTo180(sol);
                solutions = [solutions; sol];
            end
        end
    end
    
    % Remove duplicate solutions (within tolerance)
    solutions = uniquetol(solutions, 1e-6, 'ByRows', true);
end

function angle = wrapTo180(angle)
    % Wrap angle to [-180,180] range
    angle = mod(angle + 180, 360) - 180;
end